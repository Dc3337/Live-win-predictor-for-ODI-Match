readme:
Table contains columns : ['match_id', 'ball', 'innings', 'over_and_ball', 'batting_team_name',
       'batsman', 'non_striker', 'bowler', 'runs_off_bat', 'extras', 'wides',
       'no_balls', 'byes', 'leg_byes', 'penalty', 'kind_of_wicket',
       'dismissed_player', 'valid_ball', 'wicket_ball', 'runs_on_this_ball',
       'overs', 'date', 'toss_winner', 'match_winner',
       'toss_winner_chose_bat_first', 'match_country', 'runs_scored',
       'wickets_fallen', 'balls_bowled', 'req_run_rate', 'target_score',
       'innings_total_runs', 'fielding_team', 'runs_remaining',
       'wickets_in_hand', 'run_rate']

'match_id' : unique id for a match
ball: this column is redundant, you can drop this column
'innings': innings, can be 1 or 2
'over_and_ball' : this is a float valued column, containing the over and balls bowled(can be greater than 6 in one over)
'batting_team_name' : batting team name
'batsman' : batsman on strike
'non striker' : batsman on non-striker end
'bowler' : bowler
'runs_off_bat' : runs by bat
'extras' : runs constituted by byes, leg-byes, wides, no-balls etc
'wides' : runs by wides
'no_balls' : runs by no-ball
'byes' : runs by byes
'leg_byes' : runs by leg byes
'penalty' : runs by penalty such as ball hitting a helmet
'kind_of_wicket' : 'bowled', caught etc
'dismissed_player' : player out
'valid_ball' : 1 if this ball is not wide or no-ball else 0
'wicket_ball' : 1 if wicket fell in this ball else 0
'runs_on_this_ball' : runs scored on this ball
'overs' : Ongoing over starts from 0 [ correctly it should start from 1]
'date' : Match date
'toss_winner' : Team who won the toss
'match_winner' : team who won the match, NaN if "No result"
'toss_winner_chose_bat_first' : True if toss winner chose bat first
'match_country' : country of the stadium where match took place
'runs_scored' : Total runs scored after this ball [Other Suitable name would be "Scorecard_Runs"]
'wickets_fallen' : Total wickets fallen after this ball ["Scorecard_wickets"]
'balls_bowled' : Total no. of valid bowls bowled ['Scorecard_balls or overs']
'req_run_rate' : req run rate for 2nd innings team, Nan for 1st innings team
'target_score' : target score for 2nd innings team, Nan for 1st innings team
'innings_total_runs' : Total runs scored in this innings [includes the future]
'fielding_team' : team currently fielding
'runs_remaining' : how much more runs left to be scored in this innings
'wickets_in_hand' : wickets left [10 - wickets_fallen]
'run_rate' : current ongoing run rate [ runs/ balls_bowled_in_over_format] 3.5 is 3 overs and 3 bowls bowled

------------------------------------------------------------------------------------------------------------------------------------------

all_info_csv.csv contains match_id and info_dictionary

info_dictionary looks something like this,
{'balls_per_over': ['6'], 'team': ['Australia', 'Pakistan'], 'gender': ['male'], 'season': ['2016/17'], 'date': ['2017/01/13'], 'event': ['Pakistan in Australia ODI Series'], 'match_number': ['1'], 'venue': ['"Brisbane Cricket Ground', ' Woolloongabba"'], 'city': ['Brisbane'], 'toss_winner': ['Australia'], 'toss_decision': ['bat'], 'player_of_match': ['MS Wade'], 'umpire': ['MD Martell', 'C Shamshuddin'], 'reserve_umpire': ['SJ Nogajski'], 'tv_umpire': ['CB Gaffaney'], 'match_referee': ['JJ Crowe'], 'winner': ['Australia'], 'winner_runs': ['92'], 'player': ['Australia', 'DA Warner', 'Australia', 'TM Head', 'Australia', 'SPD Smith', 'Australia', 'CA Lynn', 'Australia', 'MR Marsh', 'Australia', 'GJ Maxwell', 'Australia', 'MS Wade', 'Australia', 'JP Faulkner', 'Australia', 'PJ Cummins', 'Australia', 'MA Starc', 'Australia', 'B Stanlake', 'Pakistan', 'Azhar Ali', 'Pakistan', 'Sharjeel Khan', 'Pakistan', 'Mohammad Hafeez', 'Pakistan', 'Babar Azam', 'Pakistan', 'Umar Akmal', 'Pakistan', 'Mohammad Rizwan', 'Pakistan', 'Imad Wasim', 'Pakistan', 'Mohammad Nawaz (3)', 'Pakistan', 'Mohammad Amir', 'Pakistan', 'Wahab Riaz', 'Pakistan', 'Hasan Ali'], 'registry': ['people', 'Azhar Ali', '211de69f', 'people', 'B Stanlake', '6834d1f2', 'people', 'Babar Azam', '8a75e999', 'people', 'C Shamshuddin', '0f9d921b', 'people', 'CA Lynn', '45eda7c8', 'people', 'CB Gaffaney', 'd5ac41d8', 'people', 'DA Warner', 'dcce6f09', 'people', 'GJ Maxwell', 'b681e71e', 'people', 'Hasan Ali', '2911de16', 'people', 'Imad Wasim', '9cb8d7a6', 'people', 'JJ Crowe', '2e760301', 'people', 'JP Faulkner', '808f425a', 'people', 'MA Starc', '3fb19989', 'people', 'MD Martell', '487c072e', 'people', 'MR Marsh', '3d8feaf8', 'people', 'MS Wade', 'afa7e784', 'people', 'Mohammad Amir', 'e174dadd', 'people', 'Mohammad Hafeez', '9ab63e7b', 'people', 'Mohammad Nawaz (3)', '3086f7a4', 'people', 'Mohammad Rizwan', '2f26ac1a', 'people', 'PJ Cummins', 'ded9240e', 'people', 'SJ Nogajski', '9b3f9323', 'people', 'SPD Smith', '30a45b23', 'people', 'Sharjeel Khan', '193ef196', 'people', 'TM Head', '12b610c2', 'people', 'Umar Akmal', 'fd2bf2a0', 'people', 'Wahab Riaz', 'b3118300']}



One can access this dictionary using json.loads
Ex:
def get_date_and_toss_winner_from_info(match_id: str):
    t = pd.read_csv('../data/stage_1/' + match_id + "_info.csv")
    mp = t['info_dict'][0].lstrip() #get the value in the 0th row
    mp = mp.rstrip()
    # mp = "\"" + mp + "\""
    # print(mp, len(mp))
    mp = json.loads(mp) #now mp contains the dictionary
    # print(mp)
    # print(type(mp))
    # print(mp['date'][0])
    return mp['date'][0], mp['toss_winner'][0]
    # print(t.dtypes)
get_date_and_toss_winner_from_info('1000887')